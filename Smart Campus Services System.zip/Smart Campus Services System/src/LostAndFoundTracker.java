import java.util.Scanner;

public class LostAndFoundTracker {

    static class Item {
        private int id;
        private String description;
        private String date;
        private String claimedByName;
        private String claimedByID;

        public Item(int id, String description, String date) {
            this.id = id;
            this.description = description;
            this.date = date;
            this.claimedByName = null;
            this.claimedByID = null;
        }

        public int getId() { return id; }
        public String getDescription() { return description; }
        public String getDate() { return date; }
        public String getClaimedByName() { return claimedByName; }
        public String getClaimedByID() { return claimedByID; }

        public void setDescription(String description) { this.description = description; }
        public void setDate(String date) { this.date = date; }
        public void setClaimedByName(String claimedByName) { this.claimedByName = claimedByName; }
        public void setClaimedByID(String claimedByID) { this.claimedByID = claimedByID; }
    }

    static class Node {
        public Item item;
        public Node next;

        public Node(Item item) {
            this.item = item;
            this.next = null;
        }
    }

    private Node unclaimedHead;
    private Node claimedHead;
    private int nextId;

    public LostAndFoundTracker() {
        unclaimedHead = null;
        claimedHead = null;
        nextId = 1;
    }

    public void start() {
        Scanner scanner = new Scanner(System.in);
        int choice = -1;

        while (choice != 0) {
            System.out.println("\n=== Lost and Found Tracker ===");
            System.out.println("1. Add Lost/Found Item");
            System.out.println("2. View Unclaimed Items");
            System.out.println("3. View Claimed Items");
            System.out.println("4. Claim an Item");
            System.out.println("5. Search Items by Keyword");
            System.out.println("6. Update Item Details");
            System.out.println("7. Back to Main Menu");
            System.out.print("Select an option: ");

            try {
                choice = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                choice = -1;
            }

            switch (choice) {
                case 1:
                    addItem(scanner);
                    break;
                case 2:
                    viewUnclaimedItems();
                    break;
                case 3:
                    viewClaimedItems();
                    break;
                case 4:
                    claimItem(scanner);
                    break;
                case 5:
                    searchItems(scanner);
                    break;
                case 6:
                    updateItem(scanner);
                    break;
                case 7:
                    System.out.println("Returning to Main Menu...");
                    return;
                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
    }

    private void addItem(Scanner scanner) {
        System.out.print("Enter description: ");
        String desc = scanner.nextLine();
        System.out.print("Enter date (e.g., 20-08-2025): ");
        String date = scanner.nextLine();

        Item item = new Item(nextId++, desc, date);
        Node newNode = new Node(item);
        newNode.next = unclaimedHead;
        unclaimedHead = newNode;

        System.out.println("Item added successfully with ID: " + item.getId());
    }

    private void viewUnclaimedItems() {
        if (unclaimedHead == null) {
            System.out.println("No unclaimed items.");
            return;
        }

        Node current = unclaimedHead;
        System.out.println("\n--- Unclaimed Items ---");
        while (current != null) {
            Item i = current.item;
            System.out.println("ID: " + i.getId() + " | Description: " + i.getDescription() + " | Date: " + i.getDate());
            current = current.next;
        }
    }

    private void viewClaimedItems() {
        if (claimedHead == null) {
            System.out.println("No items have been claimed yet.");
            return;
        }

        Node current = claimedHead;
        System.out.println("\n--- Claimed Items ---");
        while (current != null) {
            Item i = current.item;
            // MODIFIED: Display both student name and ID
            System.out.println("ID: " + i.getId() + " | Description: " + i.getDescription() + " | Claimed By: " + i.getClaimedByName() + " (ID: " + i.getClaimedByID() + ")");
            current = current.next;
        }
    }

    private void claimItem(Scanner scanner) {
        System.out.print("Enter the ID of the item to claim: ");
        int id;
        try {
            id = Integer.parseInt(scanner.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Invalid ID.");
            return;
        }

        Node prev = null;
        Node curr = unclaimedHead;

        while (curr != null) {
            if (curr.item.getId() == id) {
                //Ask for student name and ID
                System.out.print("Enter student name to claim this item: ");
                String claimerName = scanner.nextLine();
                System.out.print("Enter student ID to claim this item: ");
                String claimerID = scanner.nextLine();

                //Set both name and ID
                curr.item.setClaimedByName(claimerName);
                curr.item.setClaimedByID(claimerID);

                if (prev == null) {
                    unclaimedHead = curr.next;
                } else {
                    prev.next = curr.next;
                }

                curr.next = claimedHead;
                claimedHead = curr;
                // MODIFIED: Updated confirmation message
                System.out.println("Item claimed successfully by " + claimerName + " (ID: " + claimerID + ").");
                return;
            }
            prev = curr;
            curr = curr.next;
        }
        System.out.println("Item with ID " + id + " not found in unclaimed list.");
    }

    private void searchItems(Scanner scanner) {
        System.out.print("Enter keyword to search: ");
        String keyword = scanner.nextLine().toLowerCase();

        Node current = unclaimedHead;
        boolean found = false;

        System.out.println("\n--- Search Results (Unclaimed Items) ---");
        while (current != null) {
            if (current.item.getDescription().toLowerCase().contains(keyword)) {
                Item i = current.item;
                System.out.println("ID: " + i.getId() + " | Description: " + i.getDescription() + " | Date: " + i.getDate());
                found = true;
            }
            current = current.next;
        }
        if (!found) {
            System.out.println("No matching items found.");
        }
    }

    private void updateItem(Scanner scanner) {
        System.out.print("Enter the ID of the item to update (must be an unclaimed item): ");
        int id;
        try {
            id = Integer.parseInt(scanner.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Invalid ID.");
            return;
        }

        Node current = unclaimedHead;
        while (current != null) {
            if (current.item.getId() == id) {
                System.out.println("Item found. Current description: " + current.item.getDescription());
                System.out.print("Enter new description (or press Enter to keep current): ");
                String newDesc = scanner.nextLine();
                if (!newDesc.isEmpty()) {
                    current.item.setDescription(newDesc);
                }

                System.out.println("Current date: " + current.item.getDate());
                System.out.print("Enter new date (or press Enter to keep current): ");
                String newDate = scanner.nextLine();
                if (!newDate.isEmpty()) {
                    current.item.setDate(newDate);
                }

                System.out.println("Item updated successfully.");
                return;
            }
            current = current.next;
        }
        System.out.println("Item with ID " + id + " not found in unclaimed list.");
    }

    public static void main(String[] args) {
        LostAndFoundTracker tracker = new LostAndFoundTracker();
        tracker.start();
    }
}