/**
 * ADTs for booking module.
 * Defines abstract operations for managing bookings.
 */
public interface IBookingStore {
    void addBooking(String room, String date, String startTime, String endTime);
    boolean isSlotTaken(String room, String date, String startTime, String endTime);
    void cancelBooking(int id);
    void displayBookingsSorted();
}
