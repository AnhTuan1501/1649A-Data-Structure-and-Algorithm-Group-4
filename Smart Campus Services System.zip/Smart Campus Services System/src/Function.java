public interface Function {
    void addEvent();
    void deleteEvent();
    void editEvent();
    void searchEvent();
    void sortEvents();
    void displayAllEvents();
    void clearAllEvents();
}
