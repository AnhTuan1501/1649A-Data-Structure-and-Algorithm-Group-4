// AssignmentList.java

public class AssignmentList {
    private Assignment[] assignments; // Array of Assignment objects
    private int size; // Current number of assignments

    public AssignmentList(int capacity) {
        assignments = new Assignment[capacity];
        size = 0;
    }

    public void addAssignment(String title, String subject, String dueDate) {
        if (size == assignments.length) {
            System.out.println("Assignment list is full.");
            return;
        }
        assignments[size++] = new Assignment(title, subject, dueDate);
        System.out.println("Assignment added successfully.");
    }

    public void displayAll() {
        if (size == 0) {
            System.out.println("No assignments to display.");
            return;
        }
        for (int i = 0; i < size; i++) {
            assignments[i].display();
        }
    }

    public void sortByDueDate() {
        for (int i = 0; i < size - 1; i++) {
            for (int j = 0; j < size - i - 1; j++) {
                if (!assignments[j].isEarlierThan(assignments[j + 1])) {
                    Assignment temp = assignments[j];
                    assignments[j] = assignments[j + 1];
                    assignments[j + 1] = temp;
                }
            }
        }
        System.out.println("Assignments sorted by due date.");
    }

    public void search(String keyword) {
        boolean found = false;
        for (int i = 0; i < size; i++) {
            if (assignments[i].title.toLowerCase().contains(keyword.toLowerCase()) ||
                    assignments[i].subject.toLowerCase().contains(keyword.toLowerCase())) {
                assignments[i].display();
                found = true;
            }
        }
        if (!found) {
            System.out.println("No matching assignments found.");
        }
    }
}
