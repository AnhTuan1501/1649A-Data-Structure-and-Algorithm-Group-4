import java.util.Scanner;
import java.util.InputMismatchException;

public class CourseRegistrationAssistant {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        CourseManager courseManager = new CourseManager();

        courseManager.addCourse(new Course("C101", "Data Structures", "Dr. Nguyen", 30));
        courseManager.addCourse(new Course("C102", "Algorithms", "Dr. Tran", 25));
        courseManager.addCourse(new Course("C103", "Operating Systems", "Dr. Le", 20));
        courseManager.addCourse(new Course("C104", "Principle of Security", "Dr. Quoc", 20));
        courseManager.addCourse(new Course("C105", "Cybersecurity Fundamentals", "Dr. An", 25));
        courseManager.addCourse(new Course("C106", "Network Security", "Dr. Hieu", 30));
        courseManager.addCourse(new Course("C107", "Ethical Hacking", "Dr. Phuc", 15));

        CourseStudent student = new CourseStudent("S001", "Phan");

        boolean running = true;

        while (running) {
            System.out.println("=== Course Registration Assistant ===");
            System.out.println("1. Display All Courses");
            System.out.println("2. Register for a Course");
            System.out.println("3. Drop a Course");
            System.out.println("4. Search Course by ID");
            System.out.println("5. Search Course by Name");
            System.out.println("6. View Registered Courses");
            System.out.println("7. Add New Course");
            System.out.println("8. Back to Main Menu");
            System.out.print("Choose an option: ");

            int choice = -1;
            try {
                choice = scanner.nextInt();
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a number.");
                scanner.nextLine();
                continue;
            }
            scanner.nextLine();

            switch (choice) {
                case 1:
                    courseManager.displayCourses();
                    break;
                case 2:
                    System.out.print("Enter Course ID to register: ");
                    String regID = scanner.nextLine();
                    courseManager.registerCourse(student, regID);
                    break;
                case 3:
                    System.out.print("Enter Course ID to drop: ");
                    String dropID = scanner.nextLine();
                    courseManager.dropCourse(student, dropID);
                    break;
                case 4:
                    System.out.print("Enter Course ID to search: ");
                    String searchID = scanner.nextLine();
                    Course foundByID = courseManager.searchByID(searchID);
                    System.out.println(foundByID != null ? foundByID : "Course not found.");
                    break;
                case 5:
                    System.out.print("Enter Course Name to search: ");
                    String searchName = scanner.nextLine();
                    Course[] foundByName = courseManager.searchByName(searchName);
                    if (foundByName.length == 0) {
                        System.out.println("No courses found with that name.");
                    } else {
                        for (Course course : foundByName) {
                            System.out.println(course);
                        }
                    }
                    break;
                case 6:
                    System.out.println("Registered Courses:");
                    Course[] registered = student.getRegisteredCourses();
                    if (registered.length == 0) {
                        System.out.println("No registered courses.");
                    } else {
                        for (Course course : registered) {
                            System.out.println(course);
                        }
                    }
                    break;
                case 7:
                    System.out.println("Enter details for the new course:");
                    System.out.print("Course ID: ");
                    String newCourseID = scanner.nextLine();
                    System.out.print("Course Name: ");
                    String newCourseName = scanner.nextLine();
                    System.out.print("Instructor: ");
                    String newInstructor = scanner.nextLine();
                    System.out.print("Capacity: ");
                    int newCapacity = 0;
                    try {
                        newCapacity = scanner.nextInt();
                        scanner.nextLine();
                        courseManager.addCourseFromUser(newCourseID, newCourseName, newInstructor, newCapacity);
                    } catch (InputMismatchException e) {
                        System.out.println("Invalid capacity. Please enter a number.");
                        scanner.nextLine();
                    }
                    break;
                case 8:
                    System.out.println("Returning to Main Menu...");
                    return;
                default:
                    System.out.println("Invalid option. Try again.");
            }
        }
    }
}