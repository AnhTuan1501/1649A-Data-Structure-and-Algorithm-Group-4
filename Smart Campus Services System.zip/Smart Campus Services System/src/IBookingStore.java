/**
 * ADTs for booking module.
 * Defines abstract operations for managing bookings.
 */
public interface IBookingStore {
    // Core CRUD
    void addBooking(String room, String date, String startTime, String endTime);
    void editBooking(int id, String newRoom, String newDate, String newStartTime, String newEndTime);
    void cancelBooking(int id);

    // Availability / search
    boolean isSlotTaken(String room, String date, String startTime, String endTime);
    BookingArrayList<String> getAllRooms();
    BookingArrayList<String> getAvailableRooms(String date, String startTime, String endTime);
    void searchBookingsByRoom(String roomName);

    // Listing / display
    void displayBookingsSorted();
}
