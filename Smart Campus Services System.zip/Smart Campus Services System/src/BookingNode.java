/**
 * This file contains the definition of a node in a singly linked list,
 * used to store a booking object.
 */
public class BookingNode {
    Booking booking;
    BookingNode next;

    public BookingNode(Booking booking) {
        this.booking = booking;
        this.next = null;
    }
}
