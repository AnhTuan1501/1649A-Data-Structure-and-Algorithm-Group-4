public class Course {
    private String courseID;
    private String courseName;
    private String instructor;
    private int capacity;
    private int enrolled;

    public Course(String courseID, String courseName, String instructor, int capacity) {
        this.courseID = courseID;
        this.courseName = courseName;
        this.instructor = instructor;
        this.capacity = capacity;
        this.enrolled = 0;
    }

    public String getCourseID() {
        return courseID;
    }

    public String getCourseName() {
        return courseName;
    }

    public String getInstructor() {
        return instructor;
    }

    public int getCapacity() {
        return capacity;
    }

    public int getEnrolled() {
        return enrolled;
    }

    public boolean hasSpace() {
        return enrolled < capacity;
    }

    public void enrollStudent() {
        if (hasSpace())
            enrolled++;
    }

    public void dropStudent() {
        if (enrolled > 0)
            enrolled--;
    }

    @Override
    public String toString() {
        return courseID + " - " + courseName + " | Instructor: " + instructor +
                " | Capacity: " + enrolled + "/" + capacity;
    }

}
