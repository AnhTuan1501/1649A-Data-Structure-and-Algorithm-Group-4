public class CourseManager {
    private Course[] courseList;
    private int courseCount;
    private static final int INITIAL_CAPACITY = 10;

    public CourseManager() {
        this.courseList = new Course[INITIAL_CAPACITY];
        this.courseCount = 0;
    }

    public void addCourse(Course course) {
        if (courseCount >= courseList.length) {
            Course[] newArray = new Course[courseList.length * 2];
            for (int i = 0; i < courseList.length; i++) {
                newArray[i] = courseList[i];
            }
            courseList = newArray;
        }
        courseList[courseCount] = course;
        courseCount++;
    }

    public void addCourseFromUser(String courseID, String courseName, String instructor, int capacity) {
        if (searchByID(courseID) != null) {
            System.out.println("Course with this ID already exists. Cannot add.");
            return;
        }

        Course newCourse = new Course(courseID.toUpperCase(), courseName, instructor, capacity);
        addCourse(newCourse);
        System.out.println("New course '" + newCourse.getCourseName() + "' added successfully.");
    }

    public void displayCourses() {
        System.out.println("Available Courses:");
        for (int i = 0; i < courseCount; i++) {
            System.out.println(courseList[i]);
        }
    }

    public boolean registerCourse(CourseStudent student, String courseID) {
        Course course = searchByID(courseID);
        if (course == null) {
            System.out.println("Course not found. Please check the Course ID.");
            return false;
        }
        if (!course.hasSpace()) {
            System.out.println("Course is full. Cannot register at this time.");
            return false;
        }
        if (student.registerCourse(course)) {
            course.enrollStudent();
            System.out.println("Successfully registered for " + course.getCourseName());
            return true;
        } else {
            System.out.println("You are already registered for this course.");
            return false;
        }
    }

    public boolean dropCourse(CourseStudent student, String courseID) {
        Course course = searchByID(courseID);
        if (course == null) {
            System.out.println("Course not found. Please check the Course ID.");
            return false;
        }
        if (student.dropCourse(course)) {
            course.dropStudent();
            System.out.println("Successfully dropped " + course.getCourseName());
            return true;
        } else {
            System.out.println("You are not registered for this course.");
            return false;
        }
    }

    public Course searchByID(String courseID) {
        for (int i = 0; i < courseCount; i++) {
            if (courseList[i].getCourseID().equalsIgnoreCase(courseID)) {
                return courseList[i];
            }
        }
        return null;
    }

    public Course[] searchByName(String courseName) {
        Course[] tempResults = new Course[courseCount];
        int resultCount = 0;
        for (int i = 0; i < courseCount; i++) {
            if (courseList[i].getCourseName().toLowerCase().contains(courseName.toLowerCase())) {
                tempResults[resultCount] = courseList[i];
                resultCount++;
            }
        }

        Course[] results = new Course[resultCount];
        for (int i = 0; i < resultCount; i++) {
            results[i] = tempResults[i];
        }
        return results;
    }
}