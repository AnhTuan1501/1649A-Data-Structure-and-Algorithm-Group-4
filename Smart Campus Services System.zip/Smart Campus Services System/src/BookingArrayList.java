/**
 * This file used to create list for code implementation.
 */
public class BookingArrayList<E> implements Iterable<E> {
    private Object[] a = new Object[16];
    private int n = 0;

    public BookingArrayList() {}

    public int size() { return n; }
    public boolean isEmpty() { return n == 0; }

    public void add(E e) {
        if (n == a.length) grow();
        a[n++] = e;
    }

    private void grow() {
        Object[] b = new Object[a.length * 2];
        System.arraycopy(a, 0, b, 0, a.length);
        a = b;
    }

    @Override
    public java.util.Iterator<E> iterator() {
        return new java.util.Iterator<E>() {
            int i = 0;
            public boolean hasNext() { return i < n; }
            public E next() { return (E) a[i++]; }
        };
    }
}
