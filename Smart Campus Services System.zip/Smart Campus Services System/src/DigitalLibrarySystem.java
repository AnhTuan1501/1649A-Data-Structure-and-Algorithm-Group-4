import java.util.Scanner;

class Book {
    String title;
    String author;
    boolean isAvailable;

    public Book(String title, String author) {
        this.title = title;
        this.author = author;
        this.isAvailable = true;
    }
}

class BookArray {
    private Book[] books;
    private int size;

    public BookArray() {
        books = new Book[10];
        size = 0;
    }

    public void addBook(Book book) {
        if (size == books.length) {
            resize();
        }
        books[size++] = book;
    }

    private void resize() {
        Book[] newBooks = new Book[books.length * 2];
        for (int i = 0; i < books.length; i++) {
            newBooks[i] = books[i];
        }
        books = newBooks;
    }

    public Book searchByTitle(String title) {
        for (int i = 0; i < size; i++) {
            if (books[i].title.equalsIgnoreCase(title)) {
                return books[i];
            }
        }
        return null;
    }


    public Book searchByAuthor(String author) {
        for (int i = 0; i < size; i++) {
            if (books[i].author.equalsIgnoreCase(author)) {
                return books[i];
            }
        }
        return null;
    }

    public void displayAllBooks() {
        if (size == 0) {
            System.out.println("No books in the library.");
        } else {
            for (int i = 0; i < size; i++) {
                System.out.println(
                    (i + 1) + ". " + books[i].title + " by " + books[i].author + " - " +
                    (books[i].isAvailable ? "Available" : "Unavailable")
                );
            }
        }
    }
}

public class DigitalLibrarySystem {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        BookArray library = new BookArray();
        boolean running = true;

        while (running) {
            System.out.println("\n=== Digital Library System ===");
            System.out.println("1. Add a new book");
            System.out.println("2. Search book by title");
            System.out.println("3. Search book by author");
            System.out.println("4. Borrow a book");
            System.out.println("5. Return a book");
            System.out.println("6. Display all books");
            System.out.println("7. Back to Main Menu");
            System.out.print("Choose an option: ");
            int option = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (option) {
                case 1:
                    System.out.print("Enter title: ");
                    String title = scanner.nextLine();
                    System.out.print("Enter author: ");
                    String author = scanner.nextLine();
                    Book newBook = new Book(title, author);
                    library.addBook(newBook);
                    System.out.println("Book added successfully!");
                    break;
                case 2:
                    System.out.print("Enter title to search: ");
                    String searchTitle = scanner.nextLine();
                    Book foundByTitle = library.searchByTitle(searchTitle);
                    if (foundByTitle != null) {
                        System.out.println(foundByTitle.title + " by " + foundByTitle.author +
                            " - " + (foundByTitle.isAvailable ? "Available" : "Unavailable"));
                    } else {
                        System.out.println("Book not found.");
                    }
                    break;
                case 3:
                    System.out.print("Enter author to search: ");
                    String searchAuthor = scanner.nextLine();
                    Book foundByAuthor = library.searchByAuthor(searchAuthor);
                    if (foundByAuthor != null) {
                        System.out.println(foundByAuthor.title + " by " + foundByAuthor.author +
                            " - " + (foundByAuthor.isAvailable ? "Available" : "Unavailable"));
                    } else {
                        System.out.println("Book not found.");
                    }
                    break;
                case 4:
                    System.out.print("Enter title to borrow: ");
                    String borrowTitle = scanner.nextLine();
                    Book toBorrow = library.searchByTitle(borrowTitle);
                    if (toBorrow != null && toBorrow.isAvailable) {
                        toBorrow.isAvailable = false;
                        System.out.println("Book borrowed successfully!");
                    } else if (toBorrow != null) {
                        System.out.println("Book is already borrowed.");
                    } else {
                        System.out.println("Book not found.");
                    }
                    break;
                case 5:
                    System.out.print("Enter title to return: ");
                    String returnTitle = scanner.nextLine();
                    Book toReturn = library.searchByTitle(returnTitle);
                    if (toReturn != null && !toReturn.isAvailable) {
                        toReturn.isAvailable = true;
                        System.out.println("Book returned successfully!");
                    } else if (toReturn != null) {
                        System.out.println("Book is already available.");
                    } else {
                        System.out.println("Book not found.");
                    }
                    break;
                case 6:
                    library.displayAllBooks();
                    break;
                case 7:
                    System.out.println("Returning to Main Menu...");
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }
}
