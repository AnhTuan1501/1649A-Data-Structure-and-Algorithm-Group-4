public class CourseStudent {
    private String studentID;
    private String name;
    private Course[] registeredCourses;
    private int registeredCount;
    private static final int MAX_COURSES = 10;

    public CourseStudent(String studentID, String name) {
        this.studentID = studentID;
        this.name = name;
        this.registeredCourses = new Course[MAX_COURSES];
        this.registeredCount = 0;
    }

    public String getStudentID() {
        return studentID;
    }

    public String getName() {
        return name;
    }

    public Course[] getRegisteredCourses() {
        Course[] temp = new Course[registeredCount];
        for (int i = 0; i < registeredCount; i++) {
            temp[i] = registeredCourses[i];
        }
        return temp;
    }

    public boolean registerCourse(Course course) {
        if (registeredCount >= MAX_COURSES) {
            return false;
        }
        for (int i = 0; i < registeredCount; i++) {
            if (registeredCourses[i] == course) {
                return false;
            }
        }
        registeredCourses[registeredCount] = course;
        registeredCount++;
        return true;
    }

    public boolean dropCourse(Course course) {
        for (int i = 0; i < registeredCount; i++) {
            if (registeredCourses[i] == course) {
                for (int j = i; j < registeredCount - 1; j++) {
                    registeredCourses[j] = registeredCourses[j + 1];
                }
                registeredCourses[registeredCount - 1] = null;
                registeredCount--;
                return true;
            }
        }
        return false;
    }
}