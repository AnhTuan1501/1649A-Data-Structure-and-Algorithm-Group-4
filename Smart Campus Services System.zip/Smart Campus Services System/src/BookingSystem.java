import java.util.Scanner;
import java.time.LocalTime;
import java.time.LocalDate;

/**
 * This file contains a main class that is responsible for delivering user interaction for the booking system.
 */
public class BookingSystem {
    public static void main(String[] args) {
        IBookingStore list = new BookingList();
        Scanner sc = new Scanner(System.in);
        while (true) {
            System.out.println("\n=== Room Booking System ===");
            System.out.println("1. List All Rooms");
            System.out.println("2. List Available Rooms");
            System.out.println("3. Check Availability");
            System.out.println("4. Search Bookings by Room");
            System.out.println("5. Add Booking");
            System.out.println("6. Edit Booking");
            System.out.println("7. Cancel Booking");
            System.out.println("8. Display All Bookings");
            System.out.println("9. Back to Main Menu");
            System.out.print("Choice: ");

            if (!sc.hasNextLine()) {
                System.out.println("Input closed.");
                return;
            }
            String line = sc.nextLine().trim();
            if (line.isEmpty()) continue;

            int choice;
            try {
                choice = Integer.parseInt(line);
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a number.");
                continue;
            }

            switch (choice) {
                case 1: {
                    BookingArrayList<String> allRooms = list.getAllRooms();
                    System.out.println("All rooms:");
                    for (String r : allRooms) System.out.println("- " + r);
                    break;
                }
                case 2: {
                    String date = getValidatedDate(sc);
                    String startTime = getValidatedStartTime(sc);
                    String endTime = getValidatedEndTime(sc, startTime);

                    BookingArrayList<String> free = list.getAvailableRooms(date, startTime, endTime);
                    if (free.isEmpty()) {
                        System.out.println("No rooms available for " + date + " " + startTime + "–" + endTime + ".");
                    } else {
                        System.out.println("Available rooms for " + date + " " + startTime + "–" + endTime + ":");
                        for (String r : free) System.out.println("- " + r);
                    }
                    break;
                }
                case 3:
                    String roomCheck = getValidatedRoom(sc, list);
                    String dateCheck = getValidatedDate(sc);
                    String startCheck = getValidatedStartTime(sc);
                    String endCheck = getValidatedEndTime(sc, startCheck);
                    if (list.isSlotTaken(roomCheck, dateCheck, startCheck, endCheck)) {
                        System.out.println("Slot is already booked.");
                    } else {
                        System.out.println("Slot is available.");
                    }
                    break;

                case 4:
                    System.out.print("Enter room name to search: ");
                    String roomName = sc.nextLine().trim();
                    list.searchBookingsByRoom(roomName);
                    break;

                case 5:
                    String room = getValidatedRoom(sc, list);
                    String date = getValidatedDate(sc);
                    String startTime = getValidatedStartTime(sc);
                    String endTime = getValidatedEndTime(sc, startTime);
                    list.addBooking(room, date, startTime, endTime);
                    break;

                case 6:
                    int editId = getValidatedId(sc, "Enter Booking ID to edit: ");
                    String newRoom      = getValidatedRoom(sc, list);
                    String newDate      = getValidatedDate(sc);
                    String newStartTime = getValidatedStartTime(sc);
                    String newEndTime   = getValidatedEndTime(sc, newStartTime);
                    list.editBooking(editId, newRoom, newDate, newStartTime, newEndTime);
                    break;

                case 7:
                    int id = getValidatedId(sc, "Enter Booking ID to cancel: ");
                    list.cancelBooking(id);
                    break;

                case 8:
                    list.displayBookingsSorted();
                    break;

                case 9:
                    System.out.println("Returning to Main Menu...");
                    return;
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }

    // Handle wrong room name input
    private static String getValidatedRoom(Scanner sc, IBookingStore list) {
        while (true) {
            System.out.print("Enter Room: ");
            String room = sc.nextLine().trim();
            BookingArrayList<String> allRooms = list.getAllRooms();

            for (String validRoom : allRooms) {
                if (validRoom.equalsIgnoreCase(room)) {
                    return validRoom;
                }
            }

            System.out.println("Invalid room. Please choose from:");
            for (String r : allRooms) {
                System.out.println("- " + r);
            }
        }
    }

    /**
     * Handle invalid date input
     * Handle past date input
     */
    private static String getValidatedDate(Scanner sc) {
        while (true) {
            System.out.print("Enter Date (YYYY-MM-DD): ");
            String date = sc.nextLine().trim();
            try {
                LocalDate d = LocalDate.parse(date);
                if (d.isBefore(LocalDate.now())) {
                    System.out.println("Date cannot be in the past. Try again.");
                    continue;
                }
                return date;
            } catch (java.time.format.DateTimeParseException e) {
                System.out.println("Invalid date format or value. Try again.");
            }
        }
    }

    /**
     * Handle invalid time input
     * Validate startTime ensure it in business time range
     */

    private static String getValidatedStartTime(Scanner sc) {
        LocalTime OPEN = BookingList.getOpenTime();
        LocalTime CLOSE = BookingList.getCloseTime();

        while (true) {
            System.out.printf("Enter Start Time (HH:MM) [%s to before %s]: ", OPEN, CLOSE);
            String s = sc.nextLine().trim();
            try {
                LocalTime t = LocalTime.parse(s);
                if (t.isBefore(OPEN)) {
                    System.out.println("Start must be ON or AFTER " + OPEN + ".");
                    continue;
                }
                if (!t.isBefore(CLOSE)) {
                    System.out.println("Start must be BEFORE " + CLOSE + ".");
                    continue;
                }
                return s;
            } catch (Exception e) {
                System.out.println("Invalid time format. Try again (HH:MM).");
            }
        }
    }

    /**
     * Validate endTime ensure it in business timeframe and after startTime
     */
    private static String getValidatedEndTime(Scanner sc, String startStr) {
        LocalTime CLOSE = BookingList.getCloseTime();
        LocalTime start = LocalTime.parse(startStr);

        while (true) {
            System.out.printf("Enter End Time (HH:MM) [after %s, up to %s]: ", start, CLOSE);
            String s = sc.nextLine().trim();
            try {
                LocalTime end = LocalTime.parse(s);
                if (!end.isAfter(start)) {
                    System.out.println("End must be AFTER start.");
                    continue;
                }
                if (end.isAfter(CLOSE)) {
                    System.out.println("End must be ON or BEFORE " + CLOSE + ".");
                    continue;
                }
                return s;
            } catch (Exception e) {
                System.out.println("Invalid time format. Try again (HH:MM).");
            }
        }
    }

    /**
     * Validate ID input and ensure the system not crashed for invalid ID
     */
    private static int getValidatedId(Scanner sc, String prompt) {
        while (true) {
            System.out.print(prompt);
            String s = sc.nextLine().trim();
            try {
                return Integer.parseInt(s);
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a number.");
            }
        }
    }
}