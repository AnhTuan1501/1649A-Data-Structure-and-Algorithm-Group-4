import java.util.Scanner;

public class SmartCampusServicesSystem {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("\n === Smart Campus Services System ===");
            System.out.println("1. Digital Library System");
            System.out.println("2. Lost and Found Tracker");
            System.out.println("3. Assignment Planner");
            System.out.println("4. Course Registration Assistant");
            System.out.println("5. Room Booking System");
            System.out.println("6. Campus Event Calendar");
            System.out.println("7. Exit");
            System.out.print("Choice: ");

            // Handle no input
            String line = sc.nextLine().trim();
            if (line.isEmpty()) {
                System.out.println("Please enter a number (1-7).");
                continue;
            }

            // Handle wrong data type
            int choice;
            try {
                choice = Integer.parseInt(line);
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a number (1-7).");
                continue;
            }

            switch (choice) {
                case 1:
                    DigitalLibrarySystem.main(null);
                    break;
                case 2:
                    LostAndFoundTracker.main(null);
                    break;
                case 3:
                    AssignmentPlanner.main(null);
                    break;
                case 4:
                    CourseRegistrationAssistant.main(null);
                    break;
                case 5:
                    BookingSystem.main(null);
                    break;
                case 6:
                    EventCalendar.main(null);
                    break;
                case 7:
                    System.out.println("Thank you for using this system!");
                    System.exit(0);
                    return;
                default:
                    System.out.println("Invalid choice. Enter a number from 1 to 7.");
            }
        }
    }
}
