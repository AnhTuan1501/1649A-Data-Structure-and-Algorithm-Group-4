// AssignmentPlanner.java

import java.util.Scanner;

public class AssignmentPlanner {

    // Validate date format: YYYY-MM-DD
    public static boolean isValidDateFormat(String dateStr) {
        if (dateStr == null || !dateStr.matches("\\d{4}-\\d{2}-\\d{2}")) {
            return false;
        }

        String[] parts = dateStr.split("-");
        try {
            int year = Integer.parseInt(parts[0]);
            int month = Integer.parseInt(parts[1]);
            int day = Integer.parseInt(parts[2]);

            if (month < 1 || month > 12) return false;
            if (day < 1 || day > 31) return false;

            int[] daysInMonth = {31,28,31,30,31,30,31,31,30,31,30,31};
            if (day > daysInMonth[month - 1]) return false;

            return true;

        } catch (Exception e) {
            return false;
        }
    }

    // The main method for running the module
    public static void runModule() {
        Scanner scanner = new Scanner(System.in);
        AssignmentList planner = new AssignmentList(100);
        int choice;

        do {
            System.out.println("\n=== Assignment Planner Menu ===");
            System.out.println("1. Add Assignment");
            System.out.println("2. Display All Assignments");
            System.out.println("3. Sort Assignments by Due Date");
            System.out.println("4. Search Assignments by Title or Subject");
            System.out.println("5. Back to Main Menu");
            System.out.print("Enter your choice (1-5): ");
            choice = scanner.nextInt();
            scanner.nextLine(); // consume newline

            switch (choice) {
                case 1:
                    System.out.print("Enter title: ");
                    String title = scanner.nextLine();
                    System.out.print("Enter subject: ");
                    String subject = scanner.nextLine();
                    String dueDate;
                    do {
                        System.out.print("Enter due date (YYYY-MM-DD): ");
                        dueDate = scanner.nextLine();
                        if (!isValidDateFormat(dueDate)) {
                            System.out.println("Invalid format. Please use YYYY-MM-DD.");
                        }
                    } while (!isValidDateFormat(dueDate));
                    planner.addAssignment(title, subject, dueDate);
                    break;

                case 2:
                    planner.displayAll();
                    break;

                case 3:
                    planner.sortByDueDate();
                    break;

                case 4:
                    System.out.print("Enter keyword to search: ");
                    String keyword = scanner.nextLine();
                    planner.search(keyword);
                    break;

                case 5:
                    System.out.println("Returning to Main Menu...");
                    return;

                default:
                    System.out.println("Invalid choice. Try again.");
            }

        } while (true);

    }

    // Optional main method for standalone testing
    public static void main(String[] args) {
        runModule();
    }
}
