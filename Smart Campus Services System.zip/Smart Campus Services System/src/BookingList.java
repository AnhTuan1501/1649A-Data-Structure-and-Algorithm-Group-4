import java.time.LocalTime;
import java.time.LocalDateTime;
import java.time.LocalDate;

/**
 * Class to manage the list of bookings.
 * Handles adding, checking, editing, canceling, and displaying bookings.
 */
public class BookingList implements IBookingStore {

    // Linked list head node
    private BookingNode head;

    // Linked list tail node
    private BookingNode tail;
    private int size = 0;

    // Auto-increment ID for new bookings
    private int nextId = 1;

    // Define all rooms managed by the system
    private static final BookingArrayList<String> ALL_ROOMS = new BookingArrayList<>();
    static {
        for (int i = 101; i <= 120; i++) ALL_ROOMS.add(String.valueOf(i)); // Add rooms 101-120
        for (int i = 201; i <= 220; i++) ALL_ROOMS.add(String.valueOf(i)); // Add rooms 201-220
        for (int i = 301; i <= 320; i++) ALL_ROOMS.add(String.valueOf(i)); // Add rooms 301-320
        // Add special rooms
        ALL_ROOMS.add("IT Club Room");
        ALL_ROOMS.add("Art Club Room");
        ALL_ROOMS.add("Meeting Room");
        ALL_ROOMS.add("Media Club Room");
    }

    // Business hours
    private static final LocalTime OPEN_TIME = LocalTime.of(7,0); // 07:00
    private static final LocalTime CLOSE_TIME = LocalTime.of(21,0); // 21:00


    /**
     * Return all rooms managed by the system.
     */
    public BookingArrayList<String> getAllRooms() {
        BookingArrayList<String> copy = new BookingArrayList<>();
        for (String r : ALL_ROOMS) copy.add(r);
        return copy;
}

    /**
     * Add a new booking if the slot is valid and available.
     */
    public void addBooking(String room, String date, String startTime, String endTime) {
        // Convert String to LocalTime object for comparison and validation
        LocalTime start = LocalTime.parse(startTime);
        LocalTime end = LocalTime.parse(endTime);

        // Check if date in the past
        if (isDateInPast(date, start)) {
            System.out.println("Cannot create booking in the past.");
            return;
        }
        // Check if time in business timeframe
        String error = validateTimeWindow(start, end);
        if (error != null) {
            System.out.println(error);
            return;
        }

        // Check if the time slot is already booked
        if (isSlotTaken(room, date, startTime, endTime)) {
            System.out.println("Time slot unavailable.");
            return;
        }

        // Create a new booking object and linked list node
        Booking newBooking = new Booking(nextId++, room, date, startTime, endTime);
        BookingNode newNode = new BookingNode(newBooking);

        // Add a new node at the end of the linked list (O(1) with tail)
        if (head == null) {
            head = tail = newNode;
        } else {
            tail.next = newNode;
            tail = newNode;
        }
        size++; // Size increase
        System.out.println("Booking added: " + newBooking);
    }

    /**
     * Deletes a booking by its ID.
     */
    public void cancelBooking(int id) {
        if (head == null) {
            System.out.println("No bookings.");
            return;
        }

        // Delete head
        if (head.booking.getId() == id) {
            head = head.next;
            if (head == null) tail = null; // If the list is empty,tail=null
            size--;                        // Size decrease
            System.out.println("Booking cancelled.");
            return;
        }

        // Delete middle/last
        BookingNode current = head;
        while (current.next != null) {
            if (current.next.booking.getId() == id) {
                if (current.next == tail) tail = current; // Update tail if delete last node
                current.next = current.next.next;
                size--; // Size decrease
                System.out.println("Booking cancelled.");
                return;
            }
            current = current.next;
        }
        System.out.println("Booking ID not found.");
    }

    /**
     * Edits the details of an existing booking.
     */
    public void editBooking(int id, String newRoom, String newDate, String newStartTime, String newEndTime) {
       LocalTime start = LocalTime.parse(newStartTime);
       LocalTime end = LocalTime.parse(newEndTime);

       // Block past date
       if (isDateInPast(newDate, start)) {
           System.out.println("Cannot move booking to the past.");
           return;
       }

       // Re-check business hours
        String error = validateTimeWindow(start, end);
        if (error != null) {
            System.out.println(error);
            return;
        }

        BookingNode current = head;
        // Check if slot available or not
        while (current != null) {
            if (current.booking.getId() == id) {
                if (isSlotTaken(newRoom, newDate, newStartTime, newEndTime, id)) {
                    System.out.println("Time slot unavailable.");
                    return;
                }
                // Replace current booking info with new info
                current.booking.setRoom(newRoom);
                current.booking.setDate(newDate);
                current.booking.setStartTime(newStartTime);
                current.booking.setEndTime(newEndTime);
                System.out.println("Booking updated successfully.");
                return;
            }
            current = current.next;
        }
        System.out.println("Booking ID not found.");
    }


    /**
     * Checks if a time slot overlaps with existing bookings for the same room and date
     */
    // Public class use for Add / Check
    public boolean isSlotTaken(String room, String date, String startTime, String endTime) {
        return isSlotTaken(room, date, startTime, endTime, null);
    }

    // Private method: used for Edit - can exclude the booking being edited
    // Overload that accepts excludeId to skip self during overlap check.
    private boolean isSlotTaken(String room, String date, String startTime, String endTime, Integer excludeId) {
       LocalTime requestedStart = LocalTime.parse(startTime);
       LocalTime requestedEnd = LocalTime.parse(endTime);

       BookingNode current = head;
        while (current != null) {
            Booking b = current.booking;

            // skip the booking being edited (avoid self-overlap)
            if (excludeId != null && b.getId() == excludeId) {
                current = current.next;
                continue;
            }

            // If same room and date, check for overlap.
            if (b.getRoom().equalsIgnoreCase(room) && b.getDate().equals(date)) {
                LocalTime existingStart = LocalTime.parse(b.getStartTime());
                LocalTime existingEnd = LocalTime.parse(b.getEndTime());
                // Overlap rule: touching edges is not overlap
                boolean overlap = requestedStart.isBefore(existingEnd) && requestedEnd.isAfter(existingStart);
                if (overlap) return true;
            }
            current = current.next; // Move to the next node
        } return false; // NO overlap found, slot available
    }


    /**
     * Returns a list of rooms not booked yet.
     */
    public BookingArrayList<String> getAvailableRooms(String date, String startTime, String endTime) {
        BookingArrayList<String> available = new BookingArrayList<>();
        for (String room : ALL_ROOMS) {
            if (!isSlotTaken(room, date, startTime, endTime)) {
                available.add(room);
            }
        }
        return available;
    }

    /**
     * Search and display all bookings for a given room name.
     */
    public void searchBookingsByRoom(String roomName) {
        BookingNode current = head;
        boolean found = false;
        while (current != null) {
            if (current.booking.getRoom().equalsIgnoreCase(roomName)) {
                System.out.println(current.booking);
                found = true;
            }
            current = current.next;
        }
        if (!found) {
            System.out.println("No bookings found for room: " + roomName);
        }
    }


    /**
     * Displays all bookings in order by date and time.
     * Uses bubble sort on the linked list converted to array.
     */
    public void displayBookingsSorted() {
        int count = countBookings();
        if (count == 0) {
            System.out.println("No bookings to display.");
            return;
        }
        Booking[] array = new Booking[count];
        BookingNode current = head;
        int i = 0;
        while (current != null) {
            array[i++] = current.booking;
            current = current.next;
        }

        // Build key once to avoid repeated parsing
        LocalDateTime[] keys = new LocalDateTime[array.length];
        for (int k = 0; k < array.length; k++) {
            LocalDate d = LocalDate.parse(array[k].getDate());
            LocalTime t = LocalTime.parse(array[k].getStartTime());
            keys[k] = LocalDateTime.of(d, t);
        }

        // Sort bookings by date and time using bubble sort with early-exit, swap both keys and bookings
        for (int i2 = 0; i2 < array.length - 1; i2++) {
            boolean swapped = false;
            for (int j = 0; j < array.length - i2 - 1; j++) {
                if (keys[j].isAfter(keys[j + 1])) {
                    // swap keys
                    LocalDateTime kt = keys[j];
                    keys[j] = keys[j + 1];
                    keys[j + 1] = kt;
                    // swap bookings
                    Booking bt = array[j];
                    array[j] = array[j + 1];
                    array[j + 1] = bt;
                    swapped = true;
                }
            }
            if (!swapped) break; // early-exit
        }


        // Print result
        for (Booking b : array) {
            System.out.println(b);
        }
    }


    /**
     * Counts how many bookings are currently stored.
     */
    private int countBookings() {
        return size; // O(1)
    }


    public static LocalTime getOpenTime() {
        return OPEN_TIME;
    }
    public static LocalTime getCloseTime() {
        return CLOSE_TIME;
    }
    /**
     * Validate time in business time: end > start
     * StartTime and endTime both in [OPEN, CLOSE];
     */
    private String validateTimeWindow(LocalTime start, LocalTime end) {
        if (!end.isAfter(start)) {
            return "Invalid time range: endTime must be AFTER startTime.";
        }
        if (start.isBefore(OPEN_TIME)) {
            return "Invalid time: startTime must be ON or AFTER " + OPEN_TIME + ".";
        }
        if (!start.isBefore(CLOSE_TIME)) {
            return "Invalid time: startTime must be BEFORE " + CLOSE_TIME + ".";
        }
        if (end.isAfter(CLOSE_TIME)) {
            return "Invalid time: endTime must be ON or BEFORE " + CLOSE_TIME + ".";
        }
        return null;
    }


    /**
     * Block date in the past
     */
    private boolean isDateInPast(String dateStr, LocalTime start) {
        LocalDate d  = LocalDate.parse(dateStr);
        LocalDateTime dt = LocalDateTime.of(d, start);
        return dt.isBefore(LocalDateTime.now());
    }
}

