/**
 * Represent a single room booking
 * Store Booking Room ID, room name, date and start/end time
 */
public class Booking {
    private int id;            // Booking ID
    private String room;       // Room Name
    private String date;       // Booking Date
    private String startTime;  // Booking Start Time
    private String endTime;    // Booking End Time

    /**
     * Create a new Booking.
     * @param id Booking ID
     * @param room Room name
     * @param date Date of booking
     * @param startTime Start time of booking
     * @param endTime End time of booking
     */
    public Booking(int id, String room, String date, String startTime, String endTime) {
        this.id = id;
        this.room = room;
        this.date = date;
        this.startTime = startTime;
        this.endTime = endTime;
    }

    public int getId() {
        return id;
    }

    public String getRoom() {
        return room;
    }

    public String getDate() {
        return date;
    }

    public String getStartTime() {
        return startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setRoom(String room) {
        this.room = room;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public void setStartTime(String time) {
        this.startTime = time;
    }

    public void setEndTime(String time) {
        this.endTime = time;
    }

    @Override
    public String toString() {
        return "Booking ID: " + id +
                ", Room: " + room +
                ", Date: " + date +
                ", Time: " + startTime + " - " + endTime;
    }
}
