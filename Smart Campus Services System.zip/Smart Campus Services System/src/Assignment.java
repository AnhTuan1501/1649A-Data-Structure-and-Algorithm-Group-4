// Assignment.java

public class Assignment {
    public String title;
    public String subject;
    public String dueDate;
    public int year, month, day;

    // Constructor to initialize fields
    public Assignment(String title, String subject, String dueDate) {
        this.title = title;
        this.subject = subject;
        this.dueDate = dueDate;
        parseDate(dueDate);
    }

    // Parse the dueDate string (YYYY-MM-DD) into year, month, day integers
    private void parseDate(String dateStr) {
        String[] parts = dateStr.split("-");
        if (parts.length == 3) {
            this.year = Integer.parseInt(parts[0]);
            this.month = Integer.parseInt(parts[1]);
            this.day = Integer.parseInt(parts[2]);
        } else {
            this.year = this.month = this.day = 0; // Invalid fallback
        }
    }

    // Display the assignment's details
    public void display() {
        System.out.println("Title: " + title + " | Subject: " + subject + " | Due Date: " + dueDate);
    }

    // Compare dates to sort assignments
    public boolean isEarlierThan(Assignment other) {
        if (this.year != other.year) return this.year < other.year;
        if (this.month != other.month) return this.month < other.month;
        return this.day < other.day;
    }
}
